===========================================================================
Title                   : The Garden of Earthly Horrors
Filename                : earthlyhorrors.bsp
Release date            : 01/12/2021
Author                  : Richard Sherriff
Email Address           : sherriff8"gmail.com
===========================================================================
* What is included *

New levels              : Yes
Sounds                  : No
Music                   : No
Graphics                : No

* Play Information *

Single Player           : Designed for
Cooperative 2-4 Player  : No
Deathmatch 2-4 Player   : No
Difficulty Settings     : Not implemented


* Construction *

Base                    : New from scratch
Build Time              : 1 month
Editor(s) used          : Trenchbroom
Known Bugs              : None
Tested With             : Quakespasm



* Copyright / Permissions *

Authors MAY use the contents of this file as a base for
modification or reuse.  Permissions have been obtained from original 
authors for any of their resources modified or included in this file.


* Where to get the file that this text file describes *

Web sites: rsherriff.github.io/games/quakemaps.html
